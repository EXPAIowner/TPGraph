# -*- coding: utf-8 -*-
"""
"""

import torch
import torch.nn as nn
# from GCN_models import GCN
from One_hot_encoder import One_hot_encoder
import torch.nn.functional as F
import numpy as np
from Graph_Fusion import get_normalize
from torch.nn import init


class ScaledDotProductAttention(nn.Module):
    def __init__(self):
        super(ScaledDotProductAttention, self).__init__()

    def forward(self, Q, K, V):
        '''
        Q: [batch_size, n_heads, T(Spatial) or N(Temporal), N(Spatial) or T(Temporal), d_k]
        K: [batch_size, n_heads, T(Spatial) or N(Temporal), N(Spatial) or T(Temporal), d_k]
        V: [batch_size, n_heads, T(Spatial) or N(Temporal), N(Spatial) or T(Temporal), d_k]
        attn_mask: [batch_size, n_heads, seq_len, seq_len] 可能没有
        '''
        B, n_heads, len1, len2, d_k = Q.shape 
        scores = torch.matmul(Q, K.transpose(-1, -2)) / np.sqrt(d_k) 
        # scores : [batch_size, n_heads, T(Spatial) or N(Temporal), N(Spatial) or T(Temporal), N(Spatial) or T(Temporal)]
        # scores.masked_fill_(attn_mask, -1e9) # Fills elements of self tensor with value where mask is True.
        
        attn = nn.Softmax(dim=-1)(scores)
        context = torch.matmul(attn, V) # [batch_size, n_heads, T(Spatial) or N(Temporal), N(Spatial) or T(Temporal), d_k]]
        return context



class SMultiHeadAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(SMultiHeadAttention, self).__init__()
        
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert (
            self.head_dim * heads == embed_size
        ), "Embedding size needs to be divisible by heads"
            
        # 用Linear来做投影矩阵    
        # 但这里如果是多头的话，是不是需要声明多个矩阵？？？

        self.W_V = nn.Linear(self.embed_size, self.head_dim * self.heads, bias=False)
        self.W_K = nn.Linear(self.embed_size, self.head_dim * self.heads, bias=False)
        self.W_Q = nn.Linear(self.embed_size, self.head_dim * self.heads, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)
    def forward(self, input_Q, input_K, input_V):
        '''
        input_Q: [batch_size, N, T, C]
        input_K: [batch_size, N, T, C]
        input_V: [batch_size, N, T, C]
        attn_mask: [batch_size, seq_len, seq_len]
        '''
        B, N, T, C = input_Q.shape
        # [B, N, T, C] --> [B, N, T, h * d_k] --> [B, N, T, h, d_k] --> [B, h, T, N, d_k]
        Q = self.W_Q(input_Q).view(B, N, T, self.heads, self.head_dim).transpose(1, 3)  # Q: [B, h, T, N, d_k]
        K = self.W_K(input_K).view(B, N, T, self.heads, self.head_dim).transpose(1, 3)  # K: [B, h, T, N, d_k]
        V = self.W_V(input_V).view(B, N, T, self.heads, self.head_dim).transpose(1, 3)  # V: [B, h, T, N, d_k]

        # attn_mask = attn_mask.unsqueeze(1).repeat(1, n_heads, 1, 1) # attn_mask : [batch_size, n_heads, seq_len, seq_len]

        # context: [batch_size, n_heads, len_q, d_v], attn: [batch_size, n_heads, len_q, len_k]
        context = ScaledDotProductAttention()(Q, K, V) # [B, h, T, N, d_k]
        context = context.permute(0, 3, 2, 1, 4) #[B, N, T, h, d_k]
        context = context.reshape(B, N, T, self.heads * self.head_dim) # [B, N, T, C]
        # context = context.transpose(1, 2).reshape(batch_size, -1, n_heads * d_v) # context: [batch_size, len_q, n_heads * d_v]
        output = self.fc_out(context) # [batch_size, len_q, d_model]
        return output


class TMultiHeadAttention(nn.Module):
    def __init__(self, embed_size, heads):
        super(TMultiHeadAttention, self).__init__()
        
        self.embed_size = embed_size
        self.heads = heads
        self.head_dim = embed_size // heads

        assert (
            self.head_dim * heads == embed_size
        ), "Embedding size needs to be divisible by heads"
            
        # 用Linear来做投影矩阵    
        # 但这里如果是多头的话，是不是需要声明多个矩阵？？？

        self.W_V = nn.Linear(self.embed_size, self.head_dim * self.heads, bias=False)
        self.W_K = nn.Linear(self.embed_size, self.head_dim * self.heads, bias=False)
        self.W_Q = nn.Linear(self.embed_size, self.head_dim * self.heads, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)
    def forward(self, input_Q, input_K, input_V):
        '''
        input_Q: [batch_size, N, T, C]
        input_K: [batch_size, N, T, C]
        input_V: [batch_size, N, T, C]
        attn_mask: [batch_size, seq_len, seq_len]
        '''
        B, N, T, C = input_Q.shape
        # [B, N, T, C] --> [B, N, T, h * d_k] --> [B, N, T, h, d_k] --> [B, h, N, T, d_k]
        Q = self.W_Q(input_Q).view(B, N, T, self.heads, self.head_dim).permute(0, 3, 1, 2, 4) # Q: [B, h, N, T, d_k]
        K = self.W_K(input_K).view(B, N, T, self.heads, self.head_dim).permute(0, 3, 1, 2, 4)  # K: [B, h, N, T, d_k]
        V = self.W_V(input_V).view(B, N, T, self.heads, self.head_dim).permute(0, 3, 1, 2, 4)  # V: [B, h, N, T, d_k]

        # attn_mask = attn_mask.unsqueeze(1).repeat(1, n_heads, 1, 1) # attn_mask : [batch_size, n_heads, seq_len, seq_len]

        # context: [batch_size, n_heads, len_q, d_v], attn: [batch_size, n_heads, len_q, len_k]
        context = ScaledDotProductAttention()(Q, K, V) #[B, h, N, T, d_k]
        context = context.permute(0, 2, 3, 1, 4) #[B, N, T, h, d_k]
        context = context.reshape(B, N, T, self.heads * self.head_dim) # [B, N, T, C]
        # context = context.transpose(1, 2).reshape(batch_size, -1, n_heads * d_v) # context: [batch_size, len_q, n_heads * d_v]
        output = self.fc_out(context) # [batch_size, len_q, d_model]
        return output 

class GCN(nn.Module):  # GCN模型，向空域的第一个图卷积
    def __init__(self, in_c, hid_c, out_c):
        super(GCN, self).__init__()  # 表示继承父类的所有属性和方法
        self.linear_1 = nn.Linear(in_c, hid_c)  # 定义一个线性层
        self.linear_2 = nn.Linear(hid_c, out_c)  # 定义一个线性层
        # self.linear_3 = nn.Linear(64, out_c)  # 定义一个线性层


        self.act = nn.ReLU()  # 定义激活函数

    def forward(self, data, adj):

        # print("graph_data:",graph_data)
        flow_x = data  # [B, N, H, D]  流量数据

        B, N = flow_x.size(0), flow_x.size(1)  # batch_size、节点数

        flow_x = flow_x.view(B, N, -1)  # [B, N, H*D] H = 6, D = 1把最后两维缩减到一起了，这个就是把历史时间的特征放一起

        # 第一个图卷积层
        output_1 = self.linear_1(flow_x)  # [B, N, hid_C],这个就是 WX，其中W是可学习的参数，X是输入的流量数据（就是flow_x）
        output_1 = self.act(torch.matmul(adj, output_1))  # [B, N, N] ,[B, N, hid_c]，就是 \hat AWX

        # 第二个图卷积层
        output_2 = self.linear_2(output_1)  # WX
        output_2 = self.act(torch.matmul(adj, output_2))  # [B, N, 1, Out_C] , 就是 \hat AWX
        #
        # # 第二个图卷积层
        # output_3 = self.linear_3(output_2)# WX
        # output_3 = self.act(torch.matmul(graph_data, output_3))  # [B, N, 1, Out_C] , 就是 \hat AWX

        return output_2  # 第２维的维度扩张

class length_width(nn.Module):
    def __init__(self,
                 embed_size,
                 L_W  # [120,2]
                 ):
        super(length_width, self).__init__()
        self.L_W = L_W
        self.ex_liner = nn.Linear(L_W.shape[1], embed_size)

    def forward(self, B, N, T, C):  # [120,2]
        L_W = self.ex_liner(self.L_W)  # [N, C]
        L_W = L_W.expand(B, T, N, C)  # [B, T, N, C]相当于在第2维复制了T份, 第一维复制B份
        L_W = L_W.permute(0, 2, 1, 3)  # [B, N, T, C]

        return L_W


class STransformer(nn.Module):
    def __init__(self,L_W, embed_size, heads, adj1,dropout, forward_expansion):
        super(STransformer, self).__init__()
        # Spatial Embedding

        self.D_S = adj1.to('cuda:0')
        self.embed_liner = nn.Linear(adj1.shape[0], embed_size)
        self.length_width = length_width(embed_size, L_W)
        
        self.attention = SMultiHeadAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)

        self.feed_forward = nn.Sequential(
            nn.Linear(embed_size, forward_expansion * embed_size),
            nn.ReLU(),
            nn.Linear(forward_expansion * embed_size, embed_size),
        )
        
        # 调用GCN
        # self.gcn = GCN(embed_size, embed_size*2, embed_size, adj, cheb_K, dropout)
        # self.gcn=GCN(in_c=embed_size, hid_c=embed_size*2, out_c=embed_size)
        # self.norm_adj = nn.InstanceNorm2d(1)    # 对邻接矩阵归一化

        self.dropout = nn.Dropout(dropout)
        self.fs = nn.Linear(embed_size, embed_size)
        self.fg = nn.Linear(embed_size, embed_size)



    def forward(self, value, key, query,out):
        # value, key, query: [N, T, C]  [B, N, T, C]
        # A = self.adj1.to(self.device) # [N, N] 邻接矩阵，并且将数据送入设备
        # # graph_data = GCN.process_graph(graph_data)  # 变换邻接矩阵 \hat A = D_{-1/2}*A*D_{-1/2}
        # B = self.adj2.to(self.device)
        # A1 = get_normalize(A)
        # B1 = get_normalize(B)
        #
        # # print(self.weight)
        # w1, w2 = self.sigmoid(self.weight)
        # # print(w1)
        # # print(w2)
        # out = w1 * A1 + w2 * B1
        self.D_S=out
        # Spatial Embedding 部分
#         N, T, C = query.shape
#         D_S = self.embed_liner(self.D_S) # [N, C]
#         D_S = D_S.expand(T, N, C) #[T, N, C]相当于在第一维复制了T份
#         D_S = D_S.permute(1, 0, 2) #[N, T, C]
        B, N, T, C = query.shape
        D_S = self.embed_liner(self.D_S) # [N, C]
        D_S = D_S.expand(B, T, N, C) #[B, T, N, C]相当于在第2维复制了T份, 第一维复制B份
        D_S = D_S.permute(0, 2, 1, 3) #[B, N, T, C]
        
        
#         # GCN 部分
#
#
#         X_G = torch.Tensor(B, N,  0, C).to('cuda:0')
#         adj = out.unsqueeze(0).unsqueeze(0)
#         adj = self.norm_adj(adj)
#         adj = adj.squeeze(0).squeeze(0)
#
#         for t in range(query.shape[2]):
#             o = self.gcn(query[ : ,:,  t,  : ],  adj) # [B, N, C]
#             o = o.unsqueeze(2)              # shape [N, 1, C] [B, N, 1, C]
# #             print(o.shape)
#             X_G = torch.cat((X_G, o), dim=2)
         # 最后X_G [B, N, T, C]   
        
#         print('After GCN:')
#         print(X_G)
        # Spatial Transformer 部分
        query = query + D_S
        attention = self.attention(query, query, query) #(B, N, T, C)
        # Add skip connection, run through normalization and finally dropout
        x = self.dropout(self.norm1(attention + query))
        forward = self.feed_forward(x)
        U_S = self.dropout(self.norm2(forward + x))

        
        # # 融合 STransformer and GCN
        # g = torch.sigmoid(self.fs(U_S) +  self.fg(X_G))      # (7)
        # out = g*U_S + (1-g)*X_G                                # (8)

        return U_S #(B, N, T, C)




class TTransformer(nn.Module):
    def __init__(self, embed_size, heads, time_num, dropout, forward_expansion):
        super(TTransformer, self).__init__()
        
        # Temporal embedding One hot
        self.time_num = time_num
#         self.one_hot = One_hot_encoder(embed_size, time_num)          # temporal embedding选用one-hot方式 或者
        self.temporal_embedding = nn.Embedding(time_num, embed_size)  # temporal embedding选用nn.Embedding


        
        self.attention = TMultiHeadAttention(embed_size, heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)

        self.feed_forward = nn.Sequential(
            nn.Linear(embed_size, forward_expansion * embed_size),
            nn.ReLU(),
            nn.Linear(forward_expansion * embed_size, embed_size),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, value, key, query, t):
        B, N, T, C = query.shape
        
#         D_T = self.one_hot(t, N, T)                          # temporal embedding选用one-hot方式 或者
        D_T = self.temporal_embedding(torch.arange(0, T).to('cuda:0'))    # temporal embedding选用nn.Embedding
        D_T = D_T.expand(B, N, T, C)


        # temporal embedding加到query。 原论文采用concatenated
        query = query + D_T  
        
        attention = self.attention(query, query, query)

        # Add skip connection, run through normalization and finally dropout
        x = self.dropout(self.norm1(attention + query))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out




### STBlock

class STTransformerBlock(nn.Module):
    def __init__(self, L_W,embed_size, heads, adj1,adj2, time_num, cheb_K, dropout, forward_expansion,device):
        super(STTransformerBlock, self).__init__()

        self.STransformer = STransformer(L_W,embed_size, heads, adj1, dropout, forward_expansion)
        self.TTransformer = TTransformer(embed_size, heads, time_num, dropout, forward_expansion)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.dropout = nn.Dropout(dropout)
        # self.linear = nn.Linear(32, 16)
    
    def forward(self, value, key, query, out,t):
    # value,  key, query: [N, T, C] [B, N, T, C]
        # Add skip connection,run through normalization and finally dropout
        # print("value.shape:",value.shape)

        # x3 = self.norm1(self.STransformer(value, key, query,out) + query)  # [B, N, T, C]
        # x4 = self.norm2(self.TTransformer(value, key, query, t) + query)  # [B, N, T, C]
        # x5 = torch.cat([x3.permute(0, 1, 3, 2), x4.permute(0, 1, 3, 2)], 3)  # torch.cat [B, N, C, 2*T]
        #
        # # print(x5.shape)
        # # print(query.shape)
        # x6 = self.linear(x5).permute(0, 1, 3, 2) + query

        x1 = self.norm1(self.STransformer(value, key, query,out) + query) #(B, N, T, C)
        x2 = self.dropout( self.norm2(self.TTransformer(x1, x1, x1, t) + x1) )
        return x2




### Encoder
class Encoder(nn.Module):
    # 堆叠多层 ST-Transformer Block
    def __init__(
        self,
            L_W,
        embed_size,
        num_layers,
        heads,
        adj1,
        adj2,
        time_num,
        device,
        forward_expansion,
        cheb_K,
        dropout,
    ):

        super(Encoder, self).__init__()
        self.embed_size = embed_size
        self.device = device
        self.adj1 = adj1
        self.adj2 = adj2
        self.device = device
        self.weight = nn.Parameter(torch.randn(2))
        self.sigmoid = nn.Sigmoid()
        self.gcn = GCN(in_c=embed_size, hid_c=embed_size * 4, out_c=embed_size)
        self.norm_adj = nn.InstanceNorm2d(1)  # 对邻接矩阵归一化
        self.layers = nn.ModuleList(
            [
                STTransformerBlock(
                    L_W,
                    embed_size,
                    heads,
                    adj1,
                    adj2,
                    time_num,
                    cheb_K,
                    dropout=dropout,
                    forward_expansion=forward_expansion,
                    device=device
                )
                for _ in range(num_layers)
            ]
        )

        self.dropout = nn.Dropout(dropout)

    def forward(self, x, t):

        A = self.adj1.to(self.device)  # [N, N] 邻接矩阵，并且将数据送入设备
        # graph_data = GCN.process_graph(graph_data)  # 变换邻接矩阵 \hat A = D_{-1/2}*A*D_{-1/2}
        B = self.adj2.to(self.device)
        A1 = get_normalize(A)
        B1 = get_normalize(B)

        # print(self.weight)
        w1, w2 = self.sigmoid(self.weight)
        # print(w1)
        # print(w2)
        out_adj = w1 * A1 + w2 * B1

        B, N, T, C = x.shape

        # GCN 部分

        X_G = torch.Tensor(B, N, 0, C).to('cuda:0')
        # adj = out_adj.unsqueeze(0).unsqueeze(0)
        # adj = self.norm_adj(adj)
        # adj = adj.squeeze(0).squeeze(0)

        for t in range(x.shape[2]):
            o = self.gcn(x[:, :, t, :], out_adj)  # [B, N, C]
            o = o.unsqueeze(2)  # shape [N, 1, C] [B, N, 1, C]
            #             print(o.shape)
            X_G = torch.cat((X_G, o), dim=2)

        # x: [N, T, C]  [B, N, T, C]
        X_G = self.dropout(X_G+x)
        # In the Encoder the query, key, value are all the same.
        for layer in self.layers:
            X_G = layer(X_G, X_G, X_G,out_adj, t)
        return X_G
    


### Transformer   
class Transformer(nn.Module):
    def __init__(
        self,
            adj1,
            adj2,
            L_W,
        embed_size,
        num_layers,
        heads,
        time_num,
        forward_expansion, ##？
        cheb_K,
        dropout,
        
        device="cuda:0"
    ):
        super(Transformer, self).__init__()
        self.encoder = Encoder(
            L_W,
            embed_size,
            num_layers,
            heads,
            adj1,
            adj2,
            time_num,
            device,
            forward_expansion,
            cheb_K,
            dropout
        )
        self.device = device

    def forward(self, src, t): 
        ## scr: [N, T, C]   [B, N, T, C]
        enc_src = self.encoder(src, t) 
        return enc_src # [B, N, T, C]

class Pyramid(nn.Module):
    def __init__(self,
                T_dim):
        super(Pyramid, self).__init__()

        self.conv11 = nn.Conv2d(T_dim[0], T_dim[1]*2, 1, bias=False)  # b 10 120 1 -》 b 6 120 1
        self.BN1 = nn.LayerNorm(1)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv12 = nn.Conv2d(T_dim[1]*2, T_dim[1], 1)  #  b 6 120 1 --> b 3 120 1
        self.BN2 = nn.LayerNorm(1)
        self.relu2 = nn.ReLU(inplace=True)
        self.conv13 = nn.Conv2d(T_dim[1], T_dim[1], 1)  # b 3 120 1  --> b 3 120 1

        self.d = nn.Conv2d(T_dim[1], T_dim[1], 1)
        self.BNd = nn.LayerNorm(1)
        self.relud = nn.ReLU(inplace=True)

        self.w = nn.Conv2d(T_dim[1], T_dim[1], 1)
        self.BNw = nn.LayerNorm(1)
        self.reluw = nn.ReLU(inplace=True)

        self.plusNorm = nn.LayerNorm(1)

        self.conv22 = nn.Conv2d(T_dim[1], T_dim[1] * 2, 1)  # b 6 120 1
        self.BN3 = nn.LayerNorm(1)
        self.relu3 = nn.ReLU(inplace=True)
        self.conv21 = nn.Conv2d(T_dim[1] * 2, T_dim[0], 1)  # b 10 120 1
        self.BN4 = nn.LayerNorm(1)
        self.relu4 = nn.ReLU(inplace=True)

        self.con33 = nn.Conv2d(T_dim[1], T_dim[1]*2, 1)  # b 6 120 1
        self.con32 = nn.Conv2d(T_dim[1]*2, T_dim[0], 1)  # b 10 120 1
        self.con31 = nn.Conv2d(T_dim[0], 16, 1)  # b 10 120 1
        self.convend = nn.Conv2d(1, 1, 1)
    def forward(self,xc, xd, xw):  # [B,T,N,C]
        '''
        # ** ** ** xc.shape: torch.Size([32, 10, 120, 1])
        # ** ** ** xd.shape: torch.Size([32, 3, 120, 1])
        # ** ** ** xw.shape: torch.Size([32, 3, 120, 1])
        [B,T,N,C]
        '''

        up1 = xc  # b 10 120 1
        # print("up1.shape:",up1.shape)
        up2 = self.relu1(self.BN1(self.conv11(up1)))  # b 6 120 1
        # print("up2.shape:", up2.shape)
        up3 = self.relu2(self.BN2(self.conv12(up2)))  # b 3 120 1
        # print("up3.shape:", up3.shape)
        '''
        up1.shape: torch.Size([32, 10, 120, 1])
        up2.shape: torch.Size([32, 6, 120, 1])
        up3.shape: torch.Size([32, 3, 120, 1])
        [B,T,N,C]
        '''
        # print('before up3', up3[0])
        # 特征融合
        # print('xd shape',xd.shape)
        up_w=self.reluw(self.BNw(self.w(xw)))
        # print("up_w.shape:", up_w.shape) #up_w.shape: torch.Size([32, 3, 120, 1])
        up_d=self.relud(self.BNd(self.d(xd)))
        # print("up_d.shape:", up_d.shape) #up_d.shape: torch.Size([32, 3, 120, 1])
        up_c=up3 #up_c.shape: torch.Size([32, 3, 120, 1])
        # print("up_c.shape:", up_c.shape)  #up_c.shape:up3.permute(0,3,2,1)= torch.Size([32, 1, 120, 3])
        up=up_c + up_d + up_w
        # print("up shape:",up.shape) #up shape: torch.Size([32, 3, 120, 1])
        up3=self.plusNorm(up)
        # print('after 特征融合 up3 shape', up3.shape)  #after 特征融合 up3 shape torch.Size([32, 1, 120, 3])
        up3=up3
        # print("融合后的特征：",up3.shape) #融合后的特征： torch.Size([32, 3, 120, 1])


        # up3 = self.plusNorm(up3.permute(0,3,2,1) + self.relud(self.BNd(self.d(xd).permute(0,3,2,1)).permute(0,3,2,1)) + self.reluw(self.BNw(self.w(xw).permute(0,3,2,1))).permute(0,3,2,1)).permute(0,3,2,1)
        # # print('after up3',up3[0])
        # print('after 特征融合 up3 shape', up3.shape) #after 特征融合 up3 shape torch.Size([32, 3, 120, 3])

        down3 = self.conv13(up3)  # b 3 120 1
        # print("down3 shape:",down3.shape) # down3 shape: torch.Size([32, 3, 120, 1])
        down2 = self.relu3(self.BN3(self.conv22(down3)))  # b 6 120 1
        # print("down2 shape:", down2.shape) # down2 shape: torch.Size([32, 6, 120, 1])
        down1 = self.relu4(self.BN4(self.conv21(down2)))  # b 10 120 1
        # print("down1 shape:", down1.shape) # down1 shape: torch.Size([32, 10, 120, 1])

        p3 = self.con33(down3 + up3)  # b 6 120 1         torch.Size([32, 3, 120, 1]) + torch.Size([32, 3, 120, 1])= torch.Size([32, 6, 120, 1])
        p2 = self.con32(down2 + up2 + p3)  # b 10 120 3   torch.Size([32, 6, 120, 1])+torch.Size([32, 6, 120, 1])+torch.Size([32, 6, 120, 1])=torch.Size([32, 10, 120, 1])
        p1 = self.con31(down1 + up1 + p2)  # b 10 120 3   torch.Size([32, 10, 120, 1])+torch.Size([32, 10, 120, 1])+torch.Size([32, 10, 120, 1])= torch.Size([32, 10, 120, 1])
        # print('p1 shape',p1.shape) #p1 shape torch.Size([32, 10, 120, 1])
        # print("p1 p1.permute(0, 3, 2, 1) shape:",p1.permute(0, 3, 2, 1).shape) #torch.Size([32, 1, 120, 10])
        p = p1.permute(0, 3, 2, 1)
        # print("p shape:", p.shape)  # p shape: torch.Size([32, 1, 120, 10])
        # p=p.permute(0,3,2,1)

        return p  # b 1 120 10 b c n t

class selfAttention(nn.Module):
    '''
    Scaled dot-product attention
    '''

    def __init__(self, d_model, d_k, d_v, h,dropout=.1):
        '''
        :param d_model: Output dimensionality of the model
        :param d_k: Dimensionality of queries and keys
        :param d_v: Dimensionality of values
        :param h: Number of heads
        '''
        super(selfAttention, self).__init__()
        self.fc_q = nn.Linear(d_model, h * d_k)
        self.fc_k = nn.Linear(d_model, h * d_k)
        self.fc_v = nn.Linear(d_model, h * d_v)
        self.fc_o = nn.Linear(h * d_v, 16)
        self.dropout=nn.Dropout(dropout)

        self.d_model = d_model
        self.d_k = d_k
        self.d_v = d_v
        self.h = h

        self.init_weights()


    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, queries, keys, values, attention_mask=None, attention_weights=None):
        '''
        Computes
        :param queries: Queries (b_s, nq, d_model)
        :param keys: Keys (b_s, nk, d_model)
        :param values: Values (b_s, nk, d_model)
        :param attention_mask: Mask over attention values (b_s, h, nq, nk). True indicates masking.
        :param attention_weights: Multiplicative weights for attention values (b_s, h, nq, nk).
        :return:
        '''
        b_s, nq = queries.shape[:2]
        nk = keys.shape[1]

        q = self.fc_q(queries).view(b_s, nq, self.h, self.d_k).permute(0, 2, 1, 3)  # (b_s, h, nq, d_k)
        k = self.fc_k(keys).view(b_s, nk, self.h, self.d_k).permute(0, 2, 3, 1)  # (b_s, h, d_k, nk)
        v = self.fc_v(values).view(b_s, nk, self.h, self.d_v).permute(0, 2, 1, 3)  # (b_s, h, nk, d_v)

        att = torch.matmul(q, k) / np.sqrt(self.d_k)  # (b_s, h, nq, nk)
        if attention_weights is not None:
            att = att * attention_weights
        if attention_mask is not None:
            att = att.masked_fill(attention_mask, -np.inf)
        att = torch.softmax(att, -1)
        att=self.dropout(att)

        out = torch.matmul(att, v).permute(0, 2, 1, 3).contiguous().view(b_s, nq, self.h * self.d_v)  # (b_s, nq, h*d_v)
        out = self.fc_o(out)  # (b_s, nq, d_model)
        return out
class FCN(nn.Module):
    def __init__(self,T_dim):
        super(FCN, self).__init__()

        self.at_c = selfAttention(d_model=T_dim[0]+T_dim[1], d_k=T_dim[0]+T_dim[1], d_v=T_dim[0]+T_dim[1], h=8)
        self.at_d = selfAttention(d_model=T_dim[0]+T_dim[2], d_k=T_dim[0]+T_dim[2], d_v=T_dim[0]+T_dim[2], h=8)
        # self.at_w = selfAttention(d_model=T_dim[0]+T_dim[1]+T_dim[2], d_k=T_dim[0]+T_dim[1]+T_dim[2], d_v=T_dim[0]+T_dim[1]+T_dim[2], h=8)

        self.w_c=nn.Parameter(torch.randn(1))
        self.w_d=nn.Parameter(torch.randn(1))
        # self.w_w=nn.Parameter(torch.randn(1))

        # nn.Sigmoid

        # self.c_module = STmodule(block=BasicBlock,T=T_dim[0],nb_residual_unit=1)
        # self.d_module = STmodule(block=BasicBlock,T=T_dim[1],nb_residual_unit=1)
        # self.w_module = STmodule(block=BasicBlock,T=T_dim[2],nb_residual_unit=1)

    def forward(self,xc, xd, xw):
        ## B T N C
        # b 10 120 1
        # print(xc.shape)
        xc = xc.squeeze(3)
        xd = xd.squeeze(3)
        xw = xw.squeeze(3)

        xc = xc.permute(0,2,1)
        xd = xd.permute(0,2,1)
        xw = xw.permute(0,2,1)


        xcd=torch.cat([xc, xd], 2)
        xcw = torch.cat([xc, xw], 2)
        xcdw = torch.cat([xc, xd,xw], 2)

        # print(xcd.shape)
        # print(xcw.shape)
        # print(xcdw.shape)


        xc = self.at_c(xcd,xcd,xcd)
        xd = self.at_d(xcw,xcw,xcw)
        # xw = self.at_w(xcdw,xcdw,xcdw)

        xc = xc.permute(0, 2, 1)
        xd = xd.permute(0, 2, 1)
        xw = xcdw.permute(0, 2, 1)

        xc = xc.unsqueeze(3)
        xd = xd.unsqueeze(3)
        xw = xw.unsqueeze(3)


        # # print(xc.shape)
        # c_out=self.c_module(xc)
        # d_out=self.d_module(xd)
        # w_out=self.w_module(xw)
        # print("c_out shape:",c_out.shape)
        # print("d_out shape:", d_out.shape)
        # print("w_out shape:", w_out.shape)
        out=torch.add(self.w_c*xc,self.w_d*xd)
        # out=torch.add(out,self.w_w*xw)
        out=out+xw

        return out
### ST Transformer: Total Model

class STTransformer(nn.Module):
    '''
    in_channels = 1 # Channels of input
    embed_size = 64 # Dimension of hidden embedding features
    time_num = 288
    num_layers = 3 # Number of ST Block
    T_dim = 12 # Input length, should be the same as prepareData.py
    output_T_dim = 12 # Output Expected length
    heads = 2 # Number of Heads in MultiHeadAttention
    cheb_K = 2 # Order for Chebyshev Polynomials (Eq 2)
    forward_expansion = 4 # Dimension of Feed Forward Network: embed_size --> embed_size * forward_expansion --> embed_size
    dropout = 0
    '''
    def __init__(
        self, 
        adj1,
        adj2,
        L_W,
        in_channels, 
        embed_size, 
        time_num,
        num_layers,
        T_dim,
        output_T_dim,  
        heads,    
        cheb_K,
        forward_expansion,
        dropout = 0
    ):        
        super(STTransformer, self).__init__()

        self.forward_expansion = forward_expansion
        # self.Pyramid = Pyramid(T_dim)
        self.FCN = FCN(T_dim)
        # 第一次卷积扩充通道数
        self.conv1 = nn.Conv2d(in_channels, embed_size, 1)
        self.Transformer = Transformer(
            adj1,
            adj2,
            L_W,
            embed_size, 
            num_layers, 
            heads, 
            time_num,
            forward_expansion,
            cheb_K,
            dropout = 0
        )

        # 缩小时间维度。  例：T_dim=12到output_T_dim=3，输入12维降到输出3维
        self.conv2 = nn.Conv2d(16, output_T_dim, 1)
        # 缩小通道数，降到1维。
        self.conv3 = nn.Conv2d(embed_size, 1, 1)
        self.relu = nn.ReLU()
    
    def forward(self, xc, xd, xw):
        # input x shape[ C, N, T] 
        # C:通道数量。  N:传感器数量。  T:时间数量
        
#         x = x.unsqueeze(0)
        xc = xc.permute(0, 3, 2, 1)  # B T N C  # b 10 120 1
        xd = xd.permute(0, 3, 2, 1)  # b 3 120 1
        xw = xw.permute(0, 3, 2, 1)  # b 3 120 1

        input_Transformer = self.FCN(xc,xd,xw)
        input_Transformer = input_Transformer.permute(0, 3, 2, 1)

        # print("input x:",x.shape)
        input_Transformer = self.conv1(input_Transformer)
        # print("after conv:", input_Transformer.shape)
#         input_Transformer = input_Transformer.squeeze(0)
#         input_Transformer = input_Transformer.permute(1, 2, 0)
        input_Transformer = input_Transformer.permute(0, 2, 3, 1)

        
        
        
        #input_Transformer shape[N, T, C]   [B, N, T, C]
        output_Transformer = self.Transformer(input_Transformer, self.forward_expansion)  # [B, N, T, C]
        output_Transformer = output_Transformer.permute(0, 2, 1, 3)
        #output_Transformer shape[B, T, N, C]
        
#         output_Transformer = output_Transformer.unsqueeze(0)     
        out = self.relu(self.conv2(output_Transformer))    # 等号左边 out shape: [1, output_T_dim, N, C]        
        out = out.permute(0, 3, 2, 1)           # 等号左边 out shape: [B, C, N, output_T_dim]
        out = self.conv3(out)                   # 等号左边 out shape: [B, 1, N, output_T_dim]   
        out = out.squeeze(1)
        
       
        return out #[B, N, output_dim]
        # return out shape: [N, output_dim]



if __name__ == '__main__':  # 测试模型是否合适
    #(25296, 120, 1, 16)  B,N,C,T
    # (25296, 120, 1, 16)  B,N,C,T
    clossness_input = torch.randn(32, 120, 1, 10)
    clossness_input = clossness_input.reshape(32, 1, 120, 10)
    daily_input = torch.randn(32, 120, 1, 3)
    daily_input = daily_input.reshape(32, 1, 120, 3)
    weekly_input = torch.randn(32, 120, 1, 3)
    weekly_input = weekly_input.reshape(32, 1, 120, 3)
    #x shape: torch.Size([16, 1, 120, 16]) B,C,N,T
    graph1 = torch.randn(120, 120) #[B, N, N]
    # data = {"flow_x": x, "graph": graph}
    graph2 = torch.randn(120, 120)
    device = torch.device("cuda:0")
    clossness_input = clossness_input.to("cuda:0")
    daily_input = daily_input.to("cuda:0")
    weekly_input = weekly_input.to("cuda:0")
    graph1=graph1.to("cuda:0")
    graph2 = graph2.to("cuda:0")
    ### Training Hyparameter
    in_channels = 1  # Channels of input
    embed_size = 32  # Dimension of hidden embedding features
    time_num = 408
    num_layers = 2  # Number of ST Block
    T_dim = [10, 3, 3] # Input length, should be the same as prepareData.py
    output_T_dim = 3  # Output Expected length
    heads = 2  # Number of Heads in MultiHeadAttention
    cheb_K = 2  # Order for Chebyshev Polynomials (Eq 2)
    forward_expansion = 4  # Dimension of Feed Forward Network: embed_size --> embed_size * forward_expansion --> embed_size
    dropout = 0
    extra_feature = torch.Tensor(120, 2)
    extra_feature = extra_feature.to("cuda:0")
    ### Construct Network
    net = STTransformer(
        graph1,
        graph2,
        extra_feature,
        in_channels,
        embed_size,
        time_num,
        num_layers,
        T_dim,
        output_T_dim,
        heads,
        cheb_K,
        forward_expansion,
        dropout)

    net=net.to("cuda:0")
    y = net(clossness_input, daily_input, weekly_input)
    print(y.size())